﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TicTacToe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe.Tests
{
    [TestClass()]
    public class TicTacToeTests
    {
        [TestMethod()]
        public void mainTest()
        {
            TicTacToe.main();
            if (TicTacToe.isGameOver() == true)
                Assert.Fail();
        }
    }
    
    [TestClass()]
    public class TestSpaceInUse
    {
        [TestMethod()]
        public void SpaceInUseTest()
        {
            TicTacToe.main();
            if (TicTacToe.SpaceInUse(5) == true)
            {
                Assert.Fail();
            }
            else
                Assert.IsTrue(true);
        }
    }

    [TestClass()]
    public class TestWhichPlayer
    {
        [TestMethod()]
        public void WhichPlayerTest()
        {
            TicTacToe.main();
            if (TicTacToe.CurrentPlayer() == 1)
                Assert.Fail();
        }
    }

    [TestClass()]
    public class TestMakeMove
    {
        [TestMethod()]
        public void WhichMakeMove()
        {
            TicTacToe.main();
            TicTacToe.MakeMove(0);
            TicTacToe.MakeMove(0);
            if(TicTacToe.CurrentPlayer()==2)
            Assert.Fail();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    public class TicTacToe
    {
        static int[] board;
        static int currentPlayer = 1;
        static int playerOne = 1;
        static int playerTwo = 2;
        /**
         * @param args the command line arguments
         */
        public static void main()
        {
            CreateBoard();
            MakeMove(0);
            MakeMove(3);
            MakeMove(1);
            MakeMove(4);
            MakeMove(2);
        }

        //initialize an array
        public static void CreateBoard()
        {
            board = new int[8];
        }

        public static int CurrentPlayer()
        {
            return currentPlayer;
        }

        public static void MakeMove(int coord)
        {
            if (SpaceInUse(coord) == false)
            {
                board[coord] = currentPlayer;

                if (CurrentPlayer() == playerOne)
                    currentPlayer = playerTwo;
                else
                    currentPlayer = playerOne;
            }
        }

        public static bool SpaceInUse(int coord)
        {
            if (board[coord] == playerOne || board[coord] == playerTwo)
                return true;
            else
                return false;
        }

        public static bool isGameOver()
        {
            for (int x = 0; x < 3; x++)
            //straight across
            {
                if (board[x] == CurrentPlayer() && board[x + 1] == CurrentPlayer() && board[x + 2] == CurrentPlayer())
                    return true;
                //straight down
                else if (board[x] == CurrentPlayer() && board[x + 3] == CurrentPlayer() && board[x + 5] == CurrentPlayer())
                    return true;
            }
            //diag
            if (board[0] == CurrentPlayer() && board[4] == CurrentPlayer() && board[8] == CurrentPlayer())
                return true;
            //reverse diag
            else if (board[2] == CurrentPlayer() && board[4] == CurrentPlayer() && board[8] == CurrentPlayer())
                return true;
            else
                return false;

        }

    }
}
